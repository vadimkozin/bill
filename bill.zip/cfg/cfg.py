# config for bill.py
# -*- coding: utf-8 -*-

import os
import sys


def dsn(host, user, passwd, db, use_unicode=True, charset='utf8', connect_timeout=5, local_infile=0, autocommit=1):
    return dict(host=host, user=user, passwd=passwd, db=db, use_unicode=use_unicode, charset=charset,
                connect_timeout=connect_timeout, local_infile=local_infile, autocommit=autocommit)


# mysql server
_host = '192.168.200.201'

dsn_tel = dsn(host=_host, user='telefon', passwd='telefon459', db='telefon')
dsn_smg = dsn(host=_host, user='smg1016', passwd='smg6261626', db='smg')
dsn_smg2 = dsn(host=_host, user='smg1016', passwd='smg6261626', db='smg2')
dsn_rad = dsn(host=_host, user='radius', passwd='radius626', db='radius')
dsn_m200 = dsn(host=_host, user='mp12', passwd='mp12459', db='mp12')
dsn_bill = dsn(host=_host, user='mp12', passwd='mp12459', db='bill_tmp')
dsn_bill2 = dsn(host=_host, user='bill', passwd='fsx-917-edq', db='bill_tmp')
dsn_loc = dsn(host='127.0.0.1', user='root', passwd='19', db='test')
dsn_tar = dsn(host=_host, user='tarif', passwd='tarif626', db='tarif', local_infile=1)
dsn_cal = dsn(host=_host, user='calendar', passwd='cal6261626', db='calendar')
dsn_cust = dsn(host=_host, user='custom', passwd='custom459', db='customers')
dsn_cust2 = dsn(host=_host, user='customers', passwd='pas6261626', db='customers')
dsn_inet = dsn(host=_host, user='inet', passwd='inet_181901', db='inet')
dsn_webrss = dsn(host=_host, user='webrss', passwd='webrss459', db='webrss')
dsn_initel = dsn(host='10.1.1.131', user='initel', passwd='initel1901', db='initel')
dsn_fcalcint = dsn(host=_host, user='set-fcalcint', passwd='baS-506-kRa', db='billing')


# агентский тариф на ВЗ-связь для РСС и РСИ
atar_vz = dict(rss=1.1, rsi=1.1)      # old: rsi=1.2915

# параметры для вычисления стоимости
calc = dict(minsec='3')     # >= 3сек считаем

# НДС
ndskoff = 0.2       # >=2019-01


# название групповых направлений
names = dict(mgs='Россия моб.', vz='Внутризоновая')
# добавочная мапа для отображения имени на код
name2code = {
    names.get('mgs', '?'): '79',
    names.get('vz', '?'): '79',
    'Внутризоновая': '79',
    'Россия моб.': '79',
    'г. Москва * Московская область': '79',
    'Moskow-Sot': '79',
    'Услуга "800"': '7800',
    'г.Казань': '78432',
    'г.Екатеринбург': '73432',
    'НАБЕРЕЖНЫЕ ЧЕЛНЫ': '7855',
    'г.Новосибирск': '73832',
    'г.Самара': '784622',
    'г.Челябинск': '73512',
}

###
operator = dict(
    q=dict(org='rss', account='631150', prefix='A2', tab1='rss', book='rss_book', bookf='rss_bookf', serv='rss_serv',
           servf='rss_servf', akt='rss_akt', pikoff=0.23),

    q_old=dict(org='rss', account='578616', prefix='RSS', tab1='rss', book='rss_book', bookf='rss_bookf', serv='rss_serv',
           servf='rss_servf', akt='rss_akt', pikoff=0.23),

    m=dict(org='inf', account='553901', prefix='KMC', tab1='inf', book='inf_book', bookf='inf_bookf', serv='inf_serv',
           servf='inf_servf', akt='inf_akt', pikoff=0.23),
)
free800 = dict(dir='Услуга "800"', cid='800800', stat='M', serv='MG')

book = dict(MG='249', VZ='247')     # коды услуг МГ и ВЗ в программе на access

servrus = dict(MG='МГ', MN='МН', VZ='ВЗ')

stat2st = dict(G='GD', M='MG', W='MG', S='MG', Z='VZ')

# запросы
sqls = dict(
    # Основной запрос для выборки записей
    # _uf, _cid, _pid, _stat, _name, dir, sumraw, sumcust, sumoper, sumsec, summin, calls
    tab1="SELECT `_uf`, `_cid`, `_pid`, `_stat`, `_name` `dir`, Sum(`sum2`) `sumraw`, Sum(`sum`) `sumcust`, "
         " Sum(`_suma`) `sumoper`, Sum(`sec`) AS `sumsec`, Sum(`min`) `summin`, count(*) AS `calls`"
         " FROM `{tableYYYYMM}` "
         " WHERE (`p`='{operator}' AND `b`='+' AND _sum>0 AND `sec`>={minsec})"
         " GROUP BY `_uf`, `_cid`, `_pid`, `_stat`, `_name`"
         " HAVING ((`_stat` In ('M','W','S','Z'))) "
         " ORDER BY `_uf`, `_cid`, `_stat`, `_name`",


    # отбор связей на 8800
    # sumsec, summin, calls
    free800="SELECT Sum(`sec`) `sumsec`, Sum(`min`) `summin`, count(*) `calls` FROM `{tableYYYYMM}` WHERE "
            "`p`='{operator}' and `to` rlike '^(7|8)800.+' AND `sec`>='{minsec}'",

    # cid, customer, uf, contract, account, date, sum, nds, total
    book="SELECT b.cid, c.CustName customer, b.uf, c.NumDTelRssMtc contract, b.account, b.date, b.sum, b.nds, "
         "b.vsego total "
         "FROM rss_book b JOIN customers.Cust c ON b.cid=c.CustID WHERE year={year} and month={month}",

    # cid, customer, uf, contract, account, date, sum
    book_f="SELECT b.xcid cid, c.CustName customer, 'f' uf, c.f_contract_num contract, b.account, b.date, b.sum "
           "FROM rss_bookf b JOIN customers.Cust c ON b.xcid=c.CustID "
           "WHERE b.year={year} AND b.month={month}",

    # cid, customer, uf, contract, account, date, serv, sum, nds, total
    serv_u="SELECT b.cid, c.CustName customer, b.uf, c.NumDTelRssMtc contract, b.account, b.date, s.serv, "
           "s.sum, s.nds, s.vsego total FROM rss_book b "
           "JOIN rss_serv s ON b.account=s.account "
           "JOIN customers.Cust c ON b.cid=c.CustID "
           "WHERE (b.year={year} and b.month={month}) AND (s.year={year} and s.month={month}) ORDER BY b.cid",

    # cid, customer
    customers_u="SELECT b.cid, c.CustName customer FROM rss_book b JOIN customers.Cust c "
                "ON b.cid=c.CustID WHERE year={year} and month={month} AND b.uf='u'",

    # number_a, date, number_b, code, direction, min, summa
    detailed="SELECT d.fm2 number_a, d.dt `date`, d.to2 number_b, d.code, "
         "CASE "
            "WHEN d.stat='S' THEN CONCAT(d._desc,' (моб)') "
            "WHEN d.stat='Z' THEN 'Внутризоновая' "
            "ELSE d._desc "
         "END As direction, "
         "d.min, d.sum "
         "FROM {table} AS d WHERE ((d.cid={cid}) AND (d.org='R') "
         "AND (d.stat IN ('M','W','S','Z') ) AND (d.p='q') AND (d.b='+') AND (d.ok='+') AND (d.sum >0)) "
         "ORDER BY d.fm2, d.dt",

    # (FROM rss_akt): minutes, iv_d_agent, iv_d_join, summa, us, pi, av, nds
    akt="SELECT sum(min) minutes, sum(min2) iv_d_agent, sum(min3) iv_d_join, sum(sum) summa, sum(us) us, sum(pi) pi,"
        " sum(av) av, sum(nds) nds FROM rss_akt WHERE `year`={year} and `month`={month}",

    # ПОВРЕМЁНКА - оплата за минуты превышения лимита в 450мин:
    # (FROM bill.loc_book b JOIN customers.Cust): итоги по клиентам за период: account, cid, customer, uf, period, summa
    local_customer_u="SELECT b.account, c.CustID cid, c.CustName customer, b.uf, b.period, sum summa "
                "FROM {table_loc_book} b JOIN customers.Cust c ON b.cid=c.CustID WHERE b.period='{period}' "
                "AND uf='{uf}' ORDER BY b.account",

    # (FROM bill.loc_numbers b JOIN customers.Cust)
    # итоги по номерам за период: account, cid, customer, period, number, min, abon_min, prev_min, prev_cost, summa
    local_numbers="SELECT b.account, c.CustID cid, c.CustName customer, b.period, b.number, b.min, b.abmin abon_min, "
                "b.min-b.abmin prev_min, b.cost1min prev_cost, b.sum summa "
                "FROM {table_loc_numbers} b JOIN customers.Cust c ON b.cid=c.CustID WHERE b.account IN ({accounts})",

    # (FROM bill.loc_numbers):
    # список номеров одного клиента: number
    local_customer_numbers="SELECT number FROM {table_loc_numbers} WHERE period='{period}' AND cid={cid}",

    # (FROM bill.{table})
    # позвонковая детализация по номерам: date, numberA, numberB, min
    local_num_detail_fmx="SELECT dt 'date', fmX number_a, `to` number_b, min "
                         "FROM {base}.{table} WHERE stat='G' AND ({numbers})",

    local_num_detail_fm="SELECT dt 'date', fm number_a, `to` number_b, min "
                        "FROM {base}.{table} WHERE stat='G' AND ({numbers})",

    # (НЕ ПОВРЕМЁНКА) местная связь, (оплата за каждую минуту местной связи)
    mest_data="SELECT `account`, `period`, `cid`, `uf`, `min`, `cost1min`, `sum` AS `summa` FROM {base}.mest_book "
                     "WHERE `period`='{period}' ORDER BY `id`",
    # клиенты местной: cid, cust_name, cust_type, inn
    mest_customers="SELECT `CustID` cid, `CustName` cust_name, `CustType` cust_type, `INN` inn FROM customers.Cust "
                   "WHERE CustID IN ({custIds})",
    # местная - детально по клиенту: date, numberA, numberB, min
    mest_detail="SELECT `dt` 'date', `fm` numberA, `to` numberB, `min` FROM {base}.{table} " \
                "WHERE cid={cid} AND stat='G'",

    # статистика SMG - вызовы и минуты по дням за месяц
    stat_days="SELECT day(dt) day, count(*) calls, sum(min) sum_min FROM smg2.{table} GROUP BY day(dt)"

)

# root - корень проекта
root = os.path.realpath(os.path.dirname(sys.argv[0]))
# место для логирования
log = "{root}/log".format(root=root)
# резервный email (если не указан кллюч --email) для отправки результата типа 'bill_2022_06.zip'
email = 'vadim@tkrss.ru'

# пути к результирующим файлам
paths = dict(
    # корень результата
    result="{root}/result".format(root=root),
    # файлы с результатом по МГ/МН/ВЗ (utf-8) с книгой счетов и Актом (нужен для выгрузки на портал МТС)
    book=dict(dir="book"),
    # файлы (*.csv) для выгрузки на портал МТС
    mts=dict(dir="mts"),
    # местная связь для некоторых новых клиентов (считаются все минуты местной связи)
    mest=dict(dir="mest"),
    # повремёнка (превышение > 450 мин местной) для некоторых старых клиентов (почти нет)
    local=dict(dir="loc"),
    # Логирование
    logging=dict(
        load="{log}/{file}".format(log=log, file='load.log_'),
        bill="{log}/{file}".format(log=log, file='bill.log_'),
        mts="{log}/{file}".format(log=log, file='mts.log_'),
        mest="{log}/{file}".format(log=log, file='mest.log_'),
        local="{log}/{file}".format(log=log, file='local.log_'),
        info="{log}/{file}".format(log=log, file='info.log_'),
        all="{log}/{file}".format(log=log, file='all.log_'),
        codedef="{log}/{file}".format(log=log, file='codedef.log_')
    )
)